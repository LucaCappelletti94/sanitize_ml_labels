"""Current version of package sanitize_ml_label"""
__version__ = "1.0.8"
