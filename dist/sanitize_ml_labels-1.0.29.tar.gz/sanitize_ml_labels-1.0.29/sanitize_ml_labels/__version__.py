"""Current version of package sanitize_ml_labels."""
__version__ = "1.0.29"
